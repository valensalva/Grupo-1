<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/stylesconfirmar.css">
    <title> Roots </title>
</head>

<body>

    <div class="formulario">
       <img class="logo" src="/images/logo.png"> 
        <form method="POST">
            <input type="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"  name="psw" class="passwd" placeholder="Contraseña" required> <br>
            <input type="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"  name="psw2" class="passwd-repeat" placeholder="Repita la contraseña" required> <br>
            <input type="submit" name="boton2" value="Cambiar la contraseña" class="btn-recover"> <br>
        </form>    
     </div>
     
    <?php
        include 'recover.php';
    ?>
</body>

</html>