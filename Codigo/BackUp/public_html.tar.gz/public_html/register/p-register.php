<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/stylesregister.css">
    <title> Roots </title>
</head>

<body>

    <div class="formulario">
       <img class="logo" src="/images/logo.png"> 
        <form action='register.php' method="POST">
            <input type="email" name="email" class="email" placeholder="Email" pattern="[A-Za-z0-9.@_-]+" required> <br>
            <input type="text"  name="usr" class="user" placeholder="Nombre de usuario" pattern="[A-Za-z0-9._-]+" required> <br>
            <input type="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"  name="psw" class="passwd" placeholder="Contraseña" required> <br>
            <input type="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"  name="psw2" class="passwd-repeat" placeholder="Repita la contraseña" required> <br>
            
            <input type="submit" name="boton" value="Crear cuenta" class="login"> <br>     
        </form> 

            <div class="line"></div>
            <p class="middletext"> o </p> 
            <div class="line"></div>
        
        <form action='register.php' method="POST">
            <p class="text-register"> Si ya tenes una cuenta, inicia sesión</p>
            <button type="submit" formaction="../index.php" class="register">Iniciar sesión</button> 
        </form>

     </div>
    <?php
        include 'register.php';
    ?>
</body>

</html>