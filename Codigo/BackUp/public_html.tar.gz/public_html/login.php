<?php
    include('php/connect.php');

	//LOGIN
	if(isset($_POST['boton'])){
	    $usr= $_POST["usr"];
		$psw= $_POST["psw"];
        
        $query= "SELECT nombre_usuario FROM login WHERE email= '$usr' AND contrasena ='$psw'";
        $query_id = "SELECT id_user FROM usuario WHERE email= '$usr' AND contrasena ='$psw'";
        
        
        //$connect= mysqli_connect('localhost', 'id20946012_roots', 'Roots123+', 'id20946012_mydb');
        //mysqli_set_charset($connect, 'utf8');
    
        //$res= mysqli_query($connect, $query);
        $res = conexion($query);
        $array = mysqli_fetch_array($res);
        
        if( is_null($array) ) { //Si la respuesta de la primer query esta vacia, entonces el usuario no existe
    		exit;
        } else{//Si la respuesta de la primer query devuelve algo, es que el usuario existe
            //session_start();
            //$_SESSION['id'] = mysqli_query($connect, $query_id);
            header('Location: /principal/p-principal.php');
            exit;
        }
        //mysqli_close($connect);
	}
    //$_SESSION['hola'] = "hOLA";

?>