<?php
    session_start();
?>
<!DOCTYPE html>
<html>
<?php
    include('session.php');
    //include('../login.php');
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/stylesprincipal.css">
    <title> Roots </title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
    <nav class="navbar">
        <img src="../images/logo.png" class="logo">
    </nav>
    
    <main class="container"> 
        <section class="left">
            <form method="POST" class="form">
                <button type="submit" formaction="../miperfil.php" class="miperfil"> <img src="../images/myprofile.png" class="menupic"> Mi perfil </button>
                <button type="submit" formaction="../amigos.php" class="amigos"> <img src="../images/amigos.png" class="menupic">Amigos </button> 
                <button type="submit" formaction="../config.php" class="config"> <img src="../images/configuracion.png" class="menupic">Configuración </button> 
            </form> 
        </section>

        <section class="middle"> 
            <div class="postplace">
                <img src="../images/profilepic.png" class="mypic">
                <form method="POST">
                    <input type="text"  name="post" class="post" placeholder="Escribí algo acá!" required>
                    <button type="submit" name="botonPost" class="postbutton"> Publicar </button> 
                </form>
            </div>
 

            <?php
                // Te recomiendo utilizar esta conección, la que utilizas ya no es la recomendada. 
                $link = mysqli_connect('localhost', 'id20946012_roots', 'Roots123+', 'id20946012_mydb'); // el campo vaciío es para la password.
            ?>
            <?php 
            foreach ($link->query('SELECT * from Publicacion') as $row){
                echo '<div class="contain"> 
                        <img src="../images/profilepic.png" class="mypic">
                        <div class="publicacion">
                            <span class="post"> ';echo $row["texto"]; echo ' </span> 
                            <div class="info"> 
                                <input type="image" class="likes" src="../images/likes.png"> <p> 150 </p>
                                <input type="image" class="comments" src="../images/comment.png"> <p> 2 </p>
                            </div>
                        </div>
                    </div>' ?> 
            <?php
            	}
            ?>

        </section>

        <section class="right"> 
            <div class="containsearch">
                <img src="../images/search.png" class="searchimg">
                <input type="text" placeholder= "Buscá algo" class="search">
            </div>
        </section>
    </main>
<?php
    include('post.php');
?>

</body>
</html>