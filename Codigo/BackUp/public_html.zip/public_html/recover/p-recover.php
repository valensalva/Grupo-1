<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/stylesrecover.css">
    <title> Roots </title>
</head>

<body>

    <div class="formulario">
       <img class="logo" src="/images/logo.png"> 
        <form method="POST">
            <input type="email" class="email" name="email" placeholder="Email" required> <br>
            <input type="email" class="email-repeat" name="email2" placeholder="Repita el email" required> <br>
            <input type="submit" name="boton" value="Enviar email de recuperación" class="btn-recover"> <br>
        </form>    
            <div class="line"></div>
            <p class="middletext"> o </p> 
            <div class="line"></div>

            <p> Si ya tenes una cuenta, inicia sesión</p>
        <form method="POST">
            <button type="submit" formaction="/index.php" class="register">Iniciar sesión</button> 

        </form> 
     </div>
    <?php
        include 'recover.php';
    ?>
</body>

</html>