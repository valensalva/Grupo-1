<?php
    //RECOVER
    $email;
    $query;
    
    $GLOBALS['email'] = $email;
    $connect=mysqli_connect('localhost', 'id20946012_roots', 'Roots123+', 'id20946012_mydb');
    $GLOBALS['query'] = $query;
    
	if ( isset($_POST['boton']) ) {
	    $email= $_POST["email"];
	    $email2= $_POST["email2"];
	    $query= "SELECT email FROM usuario WHERE email='$email'";
	    $query2= "SELECT nombre_usuario FROM usuario WHERE email='$email'";
	    
	    $connect=mysqli_connect('localhost', 'id20946012_roots', 'Roots123+', 'id20946012_mydb');
        mysqli_set_charset($connect, 'utf8');
	    $res=mysqli_query($connect, $query);
        $array = mysqli_fetch_array($res);
        
        $usuario= mysqli_query($connect, $query2);
        $to = $email;
        $subject = "Correo de Confirmacion";
        $message = 'Hola '.$email."\r\n"."Sigue este vinculo para cambiar tu contraseña"."\r\n\r\n"."https://architectonic-boxca.000webhostapp.com/recover/p-confirmar.php"."\r\n";
        $headers = 'Hola somos de root sos un pete pa';    
    
        if ($email == $email2){
            if(is_null($array)){
                echo "este mail no es de ningun usuario";       
            } else {
                mail($to, $subject, $message, $headers);
            }
        }
	}
	
	if ( isset($_POST['boton2']) ) {
        $psw_n= $_POST["psw"];
        $psw_n2= $_POST["psw2"];
        $update= "UPDATE login SET contrasena= '$psw_n' WHERE email= '$email'";
        
        mysqli_set_charset($connect, 'utf8');
	    $res=mysqli_query($connect, $query);
        $array = mysqli_fetch_array($res);
        
        if( $psw_n == $psw_n2){ //Verifica que ambas contraseñas sean iguales
            if( is_null($array) ) { //Si la respuesta de la primer query esta vacia, entonces el usuario no existe
                echo "Este mail no es de ningun usuario"; // Se ingresa la query de ingreso de usuario 
            } else { //Si la respuesta de la primer query devuelve algo, es que el usuario existe
                mysqli_query($connect, $update); // Se cambia la contraseña nueva por la anterior
                header("Location: ../index.php");
            }
        }else{
            echo "Sos boludo";
        }
        
	}
?>