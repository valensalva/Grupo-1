<?php
    include_once('../php/connect.php');    
    
    //PUBLICACION
    if(isset($_POST['botonPost'])){
        $texto = $_POST["post"];
        $fecha = date("d-m-Y h:i:s");
        $insert = "INSERT INTO Publicacion(fecha, id_user, texto) VALUES($fecha, '0', $texto)";
        
        conexion($insert);
        //no toquen nada todavia
    }
?>