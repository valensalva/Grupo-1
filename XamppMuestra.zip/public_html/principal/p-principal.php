<?php
    include('../php/connect.php');
    $link = mysqli_connect('localhost', 'root', '', 'id20946012_mydb');
    $id_user = isset($_GET['id_user']) ? mysqli_real_escape_string($link, $_GET['id_user']) : '';
    
    $url_principal = "../principal/p-principal.php?id_user=".$id_user;
    $url_perfil = "../perfil/perfil.php?id_user=".$id_user;
    $url_config = "../config/config.php?id_user=".$id_user;
    $url_amigos = "../amigos/amigos.php?id_user=".$id_user;
    $url_login = "../index.php";
    
    $user_query = 'SELECT * FROM usuario WHERE id_user = '.$id_user; 
    $user_result = $link->query($user_query);
    $user_data = $user_result->fetch_assoc();
    $user = $user_data['nombre_usuario'];
    
    $profilepic_query = 'SELECT foto_perfil FROM usuario WHERE id_user = '.$id_user; 
    $profilepic_result = $link->query($profilepic_query);
    $profilepic_data = $profilepic_result->fetch_assoc();
    $profilepic = $profilepic_data['foto_perfil'];  

?><!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/stylesprincipal.css">
    <title> Roots </title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <link rel="icon" href="../images/logo.png">
    <style> 
            .popup-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
        }

        .popup-container img {
            max-width: 80%;
            max-height: 80%;
            border: 2px solid #fff;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
        }
    </style>

    <script>
        function showLikes(like) {
            Swal.fire("Likes: \n" + like);
        }

        function showComments(comments){
            var commentsHtml = '';
        
            comments.forEach(function(comment){
                commentsHtml += 'Usuario: ' + comment.user + '<br>';
                commentsHtml += 'Comentario: ' + comment.text + '<br>';
                commentsHtml += 'Fecha: ' + comment.date + '<br><br>';
            });
        
            Swal.fire({
                title: 'Comentarios:',
                html: commentsHtml,
                showCloseButton: true
            });
        }
    
        function abrirImg(src) {
            var contenedor = document.createElement('div');
                contenedor.className = 'popup-container';
            var imagenAmpliada = document.createElement('img');
                imagenAmpliada.src = src;
                contenedor.appendChild(imagenAmpliada);
            document.body.appendChild(contenedor);
            contenedor.addEventListener('click', function(){
                document.body.removeChild(contenedor);
            });

}

       function openCommentModal(idPublicacion) {
            var modal = document.getElementById("commentModal");
            document.getElementById("id_publicacionm").value = idPublicacion;
            modal.style.display = "block";
        }

        function closeCommentModal() {
            var modal = document.getElementById("commentModal");
            modal.style.display = "none";
        }


    </script>
</head>
<body>
    <nav class="navbar">
        <img src="../images/logo.png" class="logo">
    </nav>
    
    <main class="container"> 
        <aside class="left">
            <form method="POST" class="buttonsleft">
                <button type="submit"  formaction="<?php echo $url_principal; ?>" class="principal"> <img src="../images/casa.png" class="menupic"> Principal </button>
                <button type="submit" name="perfil" formaction="<?php echo $url_perfil; ?>" class="miperfil"> <img src="../images/myprofile.png" class="menupic"> Mi perfil </button>
                <button type="submit" formaction="<?php echo $url_amigos; ?>"  class="amigos"> <img src="../images/amigos.png" class="menupic"> Seguidos </button> 
                <button type="submit" formaction="<?php echo $url_config; ?>" class="config"> <img src="../images/configuracion.png" class="menupic">Configuración </button> 
                <button type="submit" formaction="<?php echo $url_login; ?>" class="close"> <img src="../images/close.png" class="menupic"> Cerrar Sesión </button> 
            </form> 
        </aside>

        <div class="middle"> 
            <div class="postplace">
                <div class="leftsideuser"> 
                 <?php if ($profilepic === null) {
                        echo '<a href= '.$url_perfil.'> <img src="../images/profilepic.png" class="mypic">  </a>';
                    } else {
                        echo '<a href= '.$url_perfil.'> <img src="data:image/png;base64, ' . base64_encode($profilepic) . '" class="mypic"> </a>';
                    }
                    ?>
                    <span class="usuario"> <?php echo "$user" ?></span>
                </div>
                <form method="POST" enctype="multipart/form-data">
                    <textarea name="post" class="post" placeholder="Escribí algo acá!" required></textarea>
                    <button type="submit" name="boton" class="postbutton"> Publicar </button>
                    <label class="labelimage">
                        <img src="../images/imagen.png" class="uploadimg">
                        <input type="file" name="subirimagen" class="subirimagen" > 
                    </label>
                </form>
            </div>
            <hr>
 
            <?php
            foreach ($link->query('SELECT * from Publicacion') as $row){

                $user_query = 'SELECT nombre_usuario FROM usuario WHERE id_user = '.$row["id_user"]; 
                $user_result = $link->query($user_query);
                $user_data = $user_result->fetch_assoc();
                $user = $user_data["nombre_usuario"];
                
                $cant_likes_query = "SELECT count(*) as likes FROM Likes WHERE id_publicacion = ".$row["id_publicacion"];
                $cant_likes_result = $link->query($cant_likes_query);
                $cant_likes_data = $cant_likes_result->fetch_assoc();
                $cant_likes = $cant_likes_data["likes"];
                
                $cant_comment_query = "SELECT count(*) as comments FROM Comentario WHERE id_publicacion = ".$row["id_publicacion"];
                $cant_comment_result = $link->query($cant_comment_query);
                $cant_comment_data = $cant_comment_result->fetch_assoc();
                $cant_comments = $cant_comment_data["comments"];
                
                
                $likes_query = "SELECT id_like FROM Likes WHERE id_publicacion = " . $row["id_publicacion"];
                $likes_result = $link->query($likes_query);
                $likes = array();
                $user_like = array();
                while ($likes_data = $likes_result->fetch_assoc()) {
                    $likes[] = $likes_data["id_like"];
                    $user_like_query = "SELECT nombre_usuario FROM usuario WHERE id_user = " . $likes_data["id_like"];
                    $user_like_result = $link->query($user_like_query);
                    $user_like_data = $user_like_result->fetch_assoc();
                    $user_like[] = $user_like_data["nombre_usuario"];
                }
                
                $likes_string = implode(', ', $likes);
                $user_like_string = implode(', ', $user_like);
                
                
                
                
                $comment_query = "SELECT * FROM Comentario WHERE id_publicacion = " . $row["id_publicacion"];
                $comment_result = $link->query($comment_query);
                
                $comments = array(); // Usaremos un solo array para almacenar los comentarios
                
                while ($comment_data = $comment_result->fetch_assoc()) {
                    
                    $user_comment_query = 'SELECT nombre_usuario FROM usuario WHERE id_user = '.$comment_data["id_user"]; 
                    $user_comment_result = $link->query($user_comment_query);
                    $user_comment_data = $user_comment_result->fetch_assoc();
                    
                    $user_comment = $user_comment_data["nombre_usuario"];
                
                    $comment = array(
                        "user" => $user_comment,
                        "text" => $comment_data["texto"],
                        "date" => $comment_data["fecha"]
                    );
                    $comments[] = $comment;
                }
                
                $like_veri = "SELECT * FROM Likes WHERE id_like = '$id_user' AND id_publicacion = ".$row['id_publicacion'];
                $like_veri_resultado = conexion($like_veri);
                $like_veri_array = mysqli_fetch_array($like_veri_resultado);

                if(is_null($like_veri_array)){
                    $img = '../images/likes.png';
                }else{
                    $img = '../images/likedado.png';
                }
                
                $imgresult = $link->query("SELECT imagenes FROM Publicacion WHERE id_publicacion = ".$row["id_publicacion"]);
                $image_data = $imgresult->fetch_assoc();
                $image = $image_data["imagenes"];
                
                $profilepic_result = $link->query("SELECT foto_perfil FROM usuario WHERE id_user = " .$row["id_user"]);
                $profilepic_data = $profilepic_result->fetch_assoc();
                $profilepic = $profilepic_data["foto_perfil"];
                
                $url_otrouser = "../perfil/otroperfil.php?id_user=".$id_user."&id_otrouser=". $row['id_user'];
                
                echo '<div class="contain"> 
                        <div class="leftsideuser">';
                        if ($profilepic === null) {
                            if ($row['id_user'] == $id_user) {
                                echo '<a href="' . $url_perfil . '"><img src="../images/profilepic.png" class="mypic"></a>';
                            } else {
                                echo '<a href="' . $url_otrouser . '"><img src="../images/profilepic.png" class="mypic"></a>';
                            }
                        } else {
                            if ($row['id_user'] == $id_user) {
                                echo '<a href="' . $url_perfil . '"><img src="data:image/png;base64, ' . base64_encode($profilepic) . '" class="mypic"></a>';
                            } else {
                                echo '<a href="' . $url_otrouser . '"><img src="data:image/png;base64, ' . base64_encode($profilepic) . '" class="mypic"></a>';
                            }
                        }

                echo '  </a>
                        <span class="usuario"> '. $user .' </span>
                        </div>
                        <div class="publicacion">
                            <span class="post"> '. $row["texto"] . ' </span> 
                        
                        <div class="imagenes" ';
                                if ($image === null) {
                                echo 'style="display: none;"';}
                                echo '>
                                    <img id="img" onclick="abrirImg(this.src)" src="data:image/png;base64, ' . base64_encode($row["imagenes"]) . '" class="imginpublicacion"/>
                        </div>
                            
                            <div class="info">
                                <form method="POST">
                                        <input type="hidden" name="like" value="like">
                                        <input type="hidden" name="id_publicacion" value="' . $row["id_publicacion"] . '">
                                        <input type="hidden" name="id_user" value="' . $id_user . '">
                                        <input type="image" name="like" class="likes" id="likes'.$row["id_publicacion"].'" src="'.$img.'" >
                                    </form>
                                    <button class="cant" onclick="showLikes(\''. $user_like_string .'\')" > <p> '.$cant_likes.' </p> </button>

                                    <input type="image" src="../images/comment.png" class="comments" id="comentario" onclick="openCommentModal('. $row["id_publicacion"].')">
                                    <div id="commentModal" class="modal">
                                        <div class="modal-content">
                                            <span class="closemodal" onclick="closeCommentModal()"> x </span>
                                            <form id="commentForm" method="post">
                                                <input type="hidden" name="id_publicacionm" id="id_publicacionm" value="">
                                                <input type="hidden" name="id_userm" value="' . $id_user . '">
                                                <input placeholder="Escribe tu comentario..." class="textareamodal" name="textoComentario">
                                                <button type="submit" class="buttonmodal" name="enviarComentario">Enviar Comentario</button>
                                            </form>
                                        </div>
                                    </div>

                                    <button onclick="showComments('.htmlspecialchars(json_encode($comments)).')" class="cant"> <p> '.$cant_comments.' </p> </button>
                            </div>
                        </div>
                    </div>
                    <hr class="lineasdiv">';

             }
            
            if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['like']) && isset($_POST['id_publicacion']) && isset($_POST['id_user'])){
                    $idpublicacion = mysqli_real_escape_string($link, $_POST['id_publicacion']);
                    
                    $query = "SELECT * FROM Likes WHERE id_publicacion = '$idpublicacion' AND id_like = '$id_user'";
                    
                    $res = conexion($query);
                    $array = mysqli_fetch_array($res);
                    
                    if(is_null($array)){
                        $insert = "INSERT INTO Likes(id_like, id_publicacion) VALUES('$id_user', '$idpublicacion')";
                        conexion($insert);

                    }else{
                        $delete = "DELETE FROM Likes WHERE id_publicacion = '$idpublicacion' AND id_like = '$id_user'"; 
                        conexion($delete);

                    }

                }
            ?>

        </div>

        <aside class="right"> 
            <div class="containsearch">
                <input type="text" placeholder= "Buscá una publicación o un usuario..." class="search" id="search">
            </div>
            
            <script>
                const searchInput = document.getElementById('search');
                const divdepublicaciones = document.getElementsByClassName('contain');
                const hr = document.getElementsByClassName('lineasdiv');
            
                searchInput.addEventListener('input', function() {
                    const textoabuscar = searchInput.value.toLowerCase();
            
                    for (let i = 0; i < divdepublicaciones.length; i++) {
                        const contentText = divdepublicaciones[i].textContent.toLowerCase();
                        
                        if (textoabuscar === '' || contentText.includes(textoabuscar)) {
                            divdepublicaciones[i].style.display = '';
                            hr[i].style.display = '';
                        } else {
                            divdepublicaciones[i].style.display = 'none';
                            hr[i].style.display = 'none';

                        }
                    }
                });
            </script>
        </aside>
    </main>

</body>
</html>

<?php

if (isset($_POST['boton'])) {
    $texto = $_POST["post"];
    
    if (isset($_FILES['subirimagen']) && $_FILES['subirimagen']['error'] === 0) {
        $imagen = addslashes(file_get_contents($_FILES['subirimagen']['tmp_name']));
        $insert = "INSERT INTO Publicacion(id_user, texto, imagenes) VALUES ('$id_user', '$texto', '$imagen')";
        $link->query($insert);
    } else {
        $insertsinimg = "INSERT INTO Publicacion(id_user, texto) VALUES ('$id_user', '$texto')";
        $link->query($insertsinimg);
    }

    echo "<script> Swal.fire({position: 'top', icon: 'success', title: 'La publicación se subió', showConfirmButton: false, timer: 1500}); </script>";
}

if (isset($_POST['enviarComentario'])){
    $comentario = $_POST['textoComentario'];
    $id_publicacion = $_POST['id_publicacionm'];
    $id_user = $_POST['id_userm'];

    $insertcomentario = "INSERT INTO Comentario (id_publicacion, texto, id_user) VALUES ('$id_publicacion', '$comentario', '$id_user')";
    $link->query($insertcomentario); 

    echo "<script> Swal.fire({position: 'top', icon: 'success', title: 'El comentario se subió', showConfirmButton: false, timer: 1500}); </script>";
}
?>