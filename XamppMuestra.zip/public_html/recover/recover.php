<?php
    include('../php/connect.php');
    //RECOVER
    $email;
    $query;
    
    $GLOBALS['email'] = $email;
    //connect=mysqli_connect('localhost', 'id20946012_roots', 'Roots123+', 'id20946012_mydb');
    $GLOBALS['query'] = $query;
    
	if ( isset($_POST['boton']) ) {
	    $email= $_POST["email"];
	    $email2= $_POST["email2"];
	    $query= "SELECT email FROM usuario WHERE email='$email'";
	    $user_query= "SELECT nombre_usuario FROM usuario WHERE email='$email'";
	    $id_query = "SELECT id_user FROM usuario WHERE email='$email'";
	    
	    //$connect=mysqli_connect('localhost', 'id20946012_roots', 'Roots123+', 'id20946012_mydb');
        //mysqli_set_charset($connect, 'utf8');
	    //$res=mysqli_query($connect, $query);
        
        $array = conexion($query); //mysqli_fetch_array($res);
        
        $user_result = conexion($user_query);
        $id_result = conexion($id_query);
        
        $user_data = $user_result->fetch_assoc();
        $id_data = $id_result->fetch_assoc();
        
        $user = $user_data["nombre_usuario"];
        $id = $id_data["id_user"];
        /*
        $url = 'https://architectonic-boxca.000webhostapp.com/recover/p-confirmar.php?id_user=".$id';
        $to = $email;
        $subject = "Correo de Confirmacion";
        $message = "Hola ".$user."\r\n"."Sigue este vinculo para cambiar tu contraseña"."\r\n\r\n"."<a href='$url'> Haga clik para continuar </a>";
        $headers = '<h1> Hola somos de root sos un pete pa </h1>';    */
        
        $url = 'https://architectonic-boxca.000webhostapp.com/recover/p-confirmar.php?id_user='.$id;
        $to = $email;
        $subject = "Correo de Confirmación";
        $message = "Hola $user,<br><br>";
        $message .= "Sigue este enlace para cambiar tu contraseña:<br>";
        $message .= "<a href='$url'>Haz clic para continuar</a><br><br>";
        $message .= "Saludos,<br>Tu equipo de soporte de Roots";
        
        $headers = "From: tu@email.com\r\n";
        $headers .= "Reply-To: tu@email.com\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";


        if ($email == $email2){
            if(is_null($array)){
                echo "<script> Swal.fire({icon: 'error', title: 'Oops...', text: 'El mail es incorrecto', footer: ''}) </script>";
            } else {
                mail($to, $subject, $message, $headers);
                echo "<script> Swal.fire({position: 'top-end',icon: 'success',title: 'Ya se envio el mail de confirmacion',showConfirmButton: false,timer: 1500})</script>";
            }
        }
	}
?>