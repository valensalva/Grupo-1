<?php
    include('../php/connect.php');
    $link = mysqli_connect('localhost', 'root', '', 'id20946012_mydb');
        
    if( isset($_POST['boton'])){
        $psw = $_POST["psw"];
        $psw2 = $_POST["psw2"];
        $id_user = isset($_GET['id_user']) ? mysqli_real_escape_string($link, $_GET['id_user']) : '';
        $email_query = "SELECT email FROM usuario WHERE id_user = '$id_user'";
        
        $email_result = conexion($email_query);
        $email_data = $email_result->fetch_assoc();
        $email = $email_data["email"];
        
        $update = "UPDATE login SET contrasena = '$psw' WHERE email = '$email'";
        if($psw == $psw2){
            conexion($update);
            echo "<script> Swal.fire({position: 'top-end',icon: 'success',title: 'La contraseña pudo cambiarse',showConfirmButton: false,timer: 1500})</script>";
        }else{
            echo "<script> Swal.fire({icon: 'error', title: 'Oops...', text: 'Las contraseñas son distintas', footer: ''}) </script>";
        }
    }
?>