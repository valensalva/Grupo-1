<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/stylesregister.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="icon" href="../images/logo.png">
    <title> Roots </title>
</head>

<body>

    <div class="formulario">
       <img class="logo" src="../images/logo.png"> 
        <form method="POST">
            <input type="email" name="email" class="email" placeholder="Email" pattern="[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$" required> <br>
            <input type="text"  name="usr" class="user" placeholder="Nombre de usuario" pattern="^\S+$" required> <br>
            <input type="password" pattern="^\S+$"   name="psw" class="passwd" placeholder="Contraseña" required> <br>
            <input type="password" pattern="^\S+$"  name="psw2" class="passwd-repeat" placeholder="Repita la contraseña" required> <br>
            
            <input type="submit" name="boton" value="Crear cuenta" class="login"> <br>     
        </form> 

            <div class="line"></div>
            <p class="middletext"> o </p> 
            <div class="line"></div>
        
        <form method="POST">
            <p class="text-register"> Si ya tenes una cuenta, inicia sesión</p>
            <button type="submit" formaction="../index.php" class="register">Iniciar sesión</button> 
        </form>

     </div>

</body>
<?php
    include 'register.php';
?>
</html>