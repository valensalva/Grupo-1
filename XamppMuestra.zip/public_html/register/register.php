<?php
    include('../php/connect.php');

	//REGISTER
	if ( isset($_POST['boton']) ) {
		$usr= $_POST["usr"];
    	$psw= $_POST["psw"];
    	$psw2= $_POST["psw2"];
        $email= $_POST["email"];
        
        
        $query= "SELECT * FROM login WHERE nombre_usuario = '$usr' OR email= '$email'";
		$insert= "INSERT INTO login(nombre_usuario, email, contrasena) VALUES ('$usr', '$email', '$psw')";
		$insert2= "INSERT INTO usuario(nombre_usuario, email) VALUES ('$usr', '$email')";
		
        $res = conexion($query);
        $array = mysqli_fetch_array($res);
        
        
        if(is_null($array) ) {
			if($psw == $psw2){
			    conexion($insert);
			    conexion($insert2);
				echo "<script> Swal.fire({position: 'top', icon: 'success', title: 'Su cuenta ha sido creada correctamente', showConfirmButton: false, timer: 1800}).then(() => {window.location.href='../index.php'});
				</script>";
			} else{
				echo "<script> Swal.fire({position: 'top', icon: 'error', title: 'Las contraseñas no coinciden', showConfirmButton: false, timer: 1500}); </script>";
			}
        } else {
            echo "<script> Swal.fire({position: 'top', icon: 'error', title: 'El usuario o email ya existe', showConfirmButton: false, timer: 1500}); </script>";
        }
	}
?>