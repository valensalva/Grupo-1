<?php 
    include('../php/connect.php');
    $link = mysqli_connect('localhost', 'root', '', 'id20946012_mydb');
    $id_user = isset($_GET['id_user']) ? mysqli_real_escape_string($link, $_GET['id_user']) : '';
        
    $url_principal = "../principal/p-principal.php?id_user=".$id_user;
    $url_perfil = "../perfil/perfil.php?id_user=".$id_user;
    $url_config = "../config/config.php?id_user=".$id_user;
    $url_amigos = "../amigos/amigos.php?id_user=".$id_user;
    $url_recover = "../recover/p-confirmar.php";
    $url_login = "../index.php";

    $user_query = 'SELECT * FROM usuario WHERE id_user = '.$id_user; 
    $user_result = $link->query($user_query);
    $user_data = $user_result->fetch_assoc();
    $user = $user_data['nombre_usuario'];
    
    $email_query = "SELECT email FROM usuario WHERE id_user = '$id_user'";
    $email_result = conexion($email_query);
    $email_data = $email_result->fetch_assoc();
    $email = $email_data["email"];
                    
    $desc_query = "SELECT descripcion FROM usuario WHERE id_user = '$id_user'";
    $desc_result = conexion($desc_query);
    $desc_data = $desc_result->fetch_assoc();
    $desc = $desc_data["descripcion"];
    
    
    $imgresult = $link->query("SELECT foto_perfil FROM usuario WHERE id_user = '$id_user'");
    $image_data = $imgresult->fetch_assoc();
    $image = $image_data["foto_perfil"];
    
    $profilepic_query = 'SELECT foto_perfil FROM usuario WHERE id_user = '.$id_user; 
    $profilepic_result = $link->query($profilepic_query);
    $profilepic_data = $profilepic_result->fetch_assoc();
    $profilepic = $profilepic_data['foto_perfil'];  


    
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/stylesconfig.css">
    <title> Roots </title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="icon" href="../images/logo.png">

    <script>
        function openEmail(){
            var modalEmail = document.getElementById("modalEmail");
            modalEmail.style.display = "block";
        }

        function openUser(){
            var modalUser = document.getElementById("modalUser");
            modalUser.style.display = "block";
        }

        function openDesc(){
            var modalDesc = document.getElementById("modalDesc");
            modalDesc.style.display = "block";

        }

        function openDelete(){
            var modalDelete = document.getElementById("modalDelete");
            modalDelete.style.display = "block";
        }
     
        function closeModal(){
            modalUser.style.display = "none";
            modalDesc.style.display = "none";
            modalEmail.style.display = "none";
            modalDelete.style.display = "none";

        }

    </script>
</head>
<body>
    <nav class="navbar">
            <img src="../images/logo.png" class="logo">
    </nav>

    
    <?php if ($profilepic === null) {
                            echo '<img src="../images/profilepic.png" class="profilepic">';
                        } else {
                            echo '<img src="data:image/png;base64, ' . base64_encode($profilepic) . '" class="profilepic">';
                    }
            ?>

    <main class="container"> 
        <aside class="left">
            <form method="POST" class="buttonsleft">
                <button type="submit"  formaction="<?php echo $url_principal; ?>" class="principal"> <img src="../images/casa.png" class="menupic"> Principal </button>
                <button type="submit" name="perfil" formaction="<?php echo $url_perfil; ?>" class="miperfil"> <img src="../images/myprofile.png" class="menupic"> Mi perfil </button>
                <button type="submit" formaction="<?php echo $url_amigos; ?>"  class="amigos"> <img src="../images/amigos.png" class="menupic">Seguidos  </button> 
                <button type="submit" formaction="<?php echo $url_config; ?>" class="config"> <img src="../images/configuracion.png" class="menupic">Configuración </button> 
                <button type="submit" formaction="<?php echo $url_login; ?>" class="close"> <img src="../images/close.png" class="menupic"> Cerrar Sesión </button> 
            </form> 
        </aside>

        <div class="middle">        
            <div class="middle-content"> 
                <p class="titulo"> Información Personal</p>         

                                <div class="email">
                                    <span class="info"> Dirección de email </span>
                                    <button type="submit" class="change" onclick="openEmail()"> Cambiar </button>
                                </div>

                                <div id="modalEmail" class="modal">
                                    <div class="modal-content">
                                        <span class="closemodal" onclick="closeModal()"> x </span>
                                        <form id="commentForm" method="post">
                                            <input placeholder="Ingresa tu nuevo mail..." class="textareamodal" name="textoMail">
                                            <button type="submit" class="buttonmodal" name="enviarMail"> Enviar </button>
                                        </form> 
                                    </div>
                                </div>


                                <span class="infoquery"> <?php echo "$email" ?> </span>
        
                                <div class="user">
                                    <span class="info"> Nombre de usuario </span>
                                    <button name="cambiar_usr" type="submit" class="change" onclick="openUser()"> Cambiar </button>
                                </div>

                                <div id="modalUser" class="modal">
                                    <div class="modal-content">
                                        <span class="closemodal" onclick="closeModal()"> x </span>
                                        <form id="commentForm" method="post">
                                            <input placeholder="Ingresa tu nuevo usuario..." class="textareamodal" name="textoUsuario">
                                            <button type="submit" class="buttonmodal" name="enviarUsuario"> Enviar </button>
                                        </form>
                                    </div>
                                </div>


                                <span class="infoquery"> <?php echo "$user" ?> </span>
        


                                <div class="contra">
                                    <span class="info"> Descripción </span>
                                    <button name="cambiar_desc" type="submit" class="change" onclick="openDesc()"> Cambiar </button>
                                </div>

                                <div id="modalDesc" class="modal">
                                    <div class="modal-content">
                                        <span class="closemodal" onclick="closeModal()"> x </span>
                                        <form id="commentForm" method="post">
                                            <input placeholder="Ingresa tu nueva descripción..." class="textareamodal" name="textoDesc">
                                            <button type="submit" class="buttonmodal" name="enviarDesc">Enviar</button>
                                        </form>
                                    </div>
                                </div>


                                <span class="infoquery"> <?php echo "$desc" ?> </span>
            
                                <div class="contra">
                                    <span class="info"> Contraseña </span>
                                    <form method="POST"> 
                                        <button type="submit" class="change" formaction= <?php echo "$url_recover"?>> Cambiar </button>
                                    </form>
                                </div>    

        
                                <div class="contra">
                                    <span class="info"> Foto de perfil </span>
                                
                                    <form method="POST" enctype="multipart/form-data">
                                        <label class="labelimage"> 
                                            <img src="../images/imagen.png" class="uploadimg">
                                                <input type="file" name="imagen" class="subirimagen" > 
                                            </label>
                                            <button type="submit" class="change" name="postimage"> Cambiar </button>
                                    </form>
                                </div>
                                

                        <div class="centerline">
                                    <div class="line"></div>
                                    <p class="middletext"> o  </p> 
                                    <div class="line"></div>
                        </div>

                        <div class="boton"> 
                            <button name="desactivar" onclick="openDelete()" type="submit" class="delete"> Desactivar cuenta </button>
                        </div>

                        
                        <div id="modalDelete" class="modal">
                            <div class="modal-content">
                                <span class="closemodal" onclick="closeModal()"> x </span>
                                    <form id="commentForm" method="post">
                                        <span> ¿Está seguro de que desea eliminar su cuenta?</span> <br>
                                        <span> Esta acción no se puede deshacer.</span><br>
                                        <button type="submit" class="buttonmodal" name="si">Si</button>
                                        <button type="submit" class="buttonmodal" name="no" onclick="closeModal()">No</button>
                                    </form>
                                </div>
                        </div>
            </div>
        </div>


        <div class="right">
            <div class="username"> 
                    <span class="displayname"><?php echo "$user" ?></span>
            </div>

            <span class="desc"> <?php echo "$desc" ?> </span> 


            <div class="center-content">
                <div class="right-content"> 
                    
                    </form>
                </div>
    
            </div>
        </div>

    </main>


<?php
if(isset($_POST['postimage'])){
    if(isset($_FILES['imagen']['tmp_name']) && !empty($_FILES['imagen']['tmp_name'])){
        $imagen = addslashes(file_get_contents($_FILES['imagen']['tmp_name']));
        $update = "UPDATE usuario SET foto_perfil = '$imagen' WHERE id_user = '$id_user'";
        $link->query($update);
        echo "<script> Swal.fire({position: 'top-end', icon: 'success', title: 'La foto fue actualizada', showConfirmButton: false, timer: 1500}) </script>";
    } else {
        echo "<script> Swal.fire({icon: 'error', title: 'Oops...', text: 'No se subio la imagen'}) </script>";
    }
}

if(isset($_POST['enviarMail'])){
    $n_mail = $_POST['textoMail'];
    $existeEmail= "SELECT * FROM login WHERE email= '$n_mail'";
    $resEmail = conexion($existeEmail);
    $arrayEmail = mysqli_fetch_array($resEmail);
    
    
    if(is_null($arrayEmail) ) {
        $update = "UPDATE login SET email = '$n_mail' WHERE email = '$email'";
        $update2 = "UPDATE usuario SET email = '$n_mail' WHERE id_user = '$id_user'";

        if(conexion($update) && conexion($update2)){
            echo "<script> Swal.fire({position: 'top-end', icon: 'success', title: 'El email fue actualizado', showConfirmButton: false, timer: 1500}) </script>";
        }}
    else {
            echo "<script> Swal.fire({icon: 'error', title: 'Oops...', text: 'No se pudo cambiar el email'}) </script>";
        }
}


if(isset($_POST['enviarUsuario'])){
    $n_nombre = $_POST['textoUsuario'];
    $existeUser= "SELECT * FROM login WHERE nombre_usuario= '$n_nombre'";
    $resUser= conexion($existeUser);
    $arrayUser = mysqli_fetch_array($resUser);
    
    
    if(is_null($arrayUser) ) {
        $update = "UPDATE usuario SET nombre_usuario = '$n_nombre' WHERE id_user = '$id_user'";
        $update2 = "UPDATE login SET nombre_usuario = '$n_nombre' WHERE email = '$email'";

        if(conexion($update) && conexion($update2)){
            echo "<script> Swal.fire({position: 'top-end', icon: 'success', title: 'El nombre fue actualizado', showConfirmButton: false, timer: 1500}) </script>";
        }}
    else {
            echo "<script> Swal.fire({icon: 'error', title: 'Oops...', text: 'No se pudo cambiar'}) </script>";
        }
}

if(isset($_POST['enviarDesc'])){
    $n_desc = $_POST['textoDesc'];
    
    $update = "UPDATE usuario SET descripcion = '$n_desc' WHERE id_user = '$id_user'";
    if(conexion($update)){
        echo "<script> Swal.fire({position: 'top-end', icon: 'success', title: 'La descripcion fue actualizada', showConfirmButton: false, timer: 1500}) </script>";
    }else {
        echo "<script> Swal.fire({icon: 'error', title: 'Oops...', text: 'No se pudo cambiar'}) </script>";
    }
}

if(isset($_POST['si'])){
    $borrarPublicaciones = "ALTER TABLE publicacion DROP COLUMN id_publicacion, id_user, imagenes, fecha, texto WHERE id_user = '$id_user'";
    $borrarComentarios= "ALTER TABLE comentario DROP COLUMN id_comentario, id_publicacion, id_user, imagenes, fecha, texto WHERE id_user = '$id_user'";
    $borrarLikes = "ALTER TABLE likes DROP COLUMN id_like, id_publicacion WHERE id_like = '$id_user'";
    $borrarSeguidos= "ALTER TABLE seguidorSeguido DROP COLUMN id_seguido, id_seguidor WHERE id_seguido = '$id_user' OR id_seguidor = '$id_user";
    $borrarUsuario = " ALTER TABLE usuario DROP COLUMN id_user, descripcion, foto_perfil, email, nombre_usuario WHERE id_user = '$id_user'";
    $borrarLogin = "ALTER TABLE login DROP COLUMN email, nombre_usuario, contrasena WHERE email = '$email'";
    if(conexion($borrarPublicaciones) && conexion($borrarComentarios) && conexion($borrarLikes) && conexion($borrarSeguidos) && conexion($borrarUsuario) && conexion($borrarLogin)){
        echo "<script> Swal.fire({position: 'top', icon: 'success', title: 'Su cuenta ha sido eliminada correctamente. Esperamos que vuelvas!', showConfirmButton: false, timer: 2000}).then(() => {window.location.href='../index.php'});
        </script>";
    } else{
        echo "<script> Swal.fire({position: 'top', icon: 'error', title: 'No ha sido posible eliminar su cuenta, intente de nuevo', showConfirmButton: false, timer: 1500}); </script>";
    }
}

?>

</body>
</html>
