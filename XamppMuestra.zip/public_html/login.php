<?php
    include('php/connect.php');
    
    //LOGIN
    if(isset($_POST['boton'])){
        $email= $_POST["usr"];
    	$psw= $_POST["psw"];
        
        $query= "SELECT nombre_usuario FROM login WHERE email= '$email' AND contrasena='$psw'";
        $query_id = "SELECT id_user FROM usuario WHERE email= '$email'";
    
        $res = conexion($query);
        $array = mysqli_fetch_array($res);
        
        if(is_null($array) ) {
            echo "<script> Swal.fire({position: 'top', icon: 'error', title: 'El email o contraseña son incorrectos', showConfirmButton: false, timer: 1500}); </script>";
        } else{
            $id_user_result = conexion($query_id);
            $id_user_row = mysqli_fetch_assoc($id_user_result);
            $id_user = $id_user_row['id_user'];
            echo '
            <script> window.location.href="principal/p-principal.php?id_user='.$id_user.'" </script>';
        }
    }
?>